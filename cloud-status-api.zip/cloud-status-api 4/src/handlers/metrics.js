const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { getCached, setCache } = require('../config/redis');

// GET /api/v1/metrics/uptime - Uptime percentages
router.get('/uptime', async (req, res) => {
  try {
    const cached = await getCached('uptime_metrics');
    if (cached) return res.json({ data: cached });

    const result = await query(`
      SELECT s.name, s.slug,
             u.uptime_30d, u.uptime_60d, u.uptime_90d,
             u.total_incidents_30d, u.mttr_minutes
      FROM services s
      JOIN service_uptime u ON s.id = u.service_id
      WHERE s.is_active = true
      ORDER BY u.uptime_30d ASC
    `);

    await setCache('uptime_metrics', result.rows, 300);
    res.json({ data: result.rows });
  } catch (err) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
