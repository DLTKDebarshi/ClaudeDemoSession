const express = require('express');
const router = express.Router();
const Joi = require('joi');
const { query } = require('../config/database');
const { logger } = require('../config/logger');

const incidentSchema = Joi.object({
  service_id: Joi.number().integer().required(),
  title: Joi.string().max(200).required(),
  description: Joi.string().max(2000).required(),
  severity: Joi.string().valid('P1', 'P2', 'P3', 'P4').required(),
  reported_by: Joi.string().email().required(),
});

// GET /api/v1/incidents - Active incidents
router.get('/', async (req, res) => {
  try {
    const { status, severity, limit = 20, offset = 0 } = req.query;
    
    let sql = `
      SELECT i.*, s.name as service_name, s.slug as service_slug
      FROM incidents i
      JOIN services s ON i.service_id = s.id
      WHERE 1=1
    `;
    const params = [];

    if (status) {
      params.push(status);
      sql += ` AND i.status = $${params.length}`;
    }
    if (severity) {
      params.push(severity);
      sql += ` AND i.severity = $${params.length}`;
    }

    sql += ` ORDER BY i.created_at DESC`;
    params.push(limit);
    sql += ` LIMIT $${params.length}`;
    params.push(offset);
    sql += ` OFFSET $${params.length}`;

    const result = await query(sql, params);
    res.json({ data: result.rows, total: result.rowCount });
  } catch (err) {
    logger.error('Failed to fetch incidents:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/v1/incidents - Report new incident
router.post('/', async (req, res) => {
  try {
    const { error, value } = incidentSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const { service_id, title, description, severity, reported_by } = value;

    const result = await query(`
      INSERT INTO incidents (service_id, title, description, severity, reported_by, status, created_at)
      VALUES ($1, $2, $3, $4, $5, 'investigating', NOW())
      RETURNING *
    `, [service_id, title, description, severity, reported_by]);

    // TODO: Send PagerDuty alert for P1/P2
    // TODO: Post to Slack #cloud-incidents
    // TODO: Update service status to degraded/outage

    logger.info(`New incident reported: ${title} (${severity})`);
    res.status(201).json({ data: result.rows[0] });
  } catch (err) {
    logger.error('Failed to create incident:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
