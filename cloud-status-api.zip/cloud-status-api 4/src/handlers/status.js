const express = require('express');
const router = express.Router();
const { query } = require('../config/database');
const { getCached, setCache } = require('../config/redis');
const { logger } = require('../config/logger');

// GET /api/v1/status - All service statuses
router.get('/', async (req, res) => {
  try {
    // Check cache first
    const cached = await getCached('all_statuses');
    if (cached) {
      return res.json({ data: cached, source: 'cache' });
    }

    const result = await query(`
      SELECT s.id, s.name, s.slug, s.description, 
             ss.status, ss.response_time_ms, ss.checked_at,
             COALESCE(u.uptime_30d, 0) as uptime_30d
      FROM services s
      LEFT JOIN service_status ss ON s.id = ss.service_id 
        AND ss.checked_at = (SELECT MAX(checked_at) FROM service_status WHERE service_id = s.id)
      LEFT JOIN service_uptime u ON s.id = u.service_id
      WHERE s.is_active = true
      ORDER BY s.display_order
    `);

    const data = result.rows;
    await setCache('all_statuses', data, 30);

    res.json({ data, source: 'database' });
  } catch (err) {
    logger.error('Failed to fetch statuses:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /api/v1/status/:service - Single service status
router.get('/:service', async (req, res) => {
  try {
    const { service } = req.params;
    
    // BUG: No input validation on service parameter - SQL injection possible
    const result = await query(`
      SELECT s.*, ss.status, ss.response_time_ms, ss.checked_at,
             ss.error_message,
             u.uptime_30d, u.uptime_60d, u.uptime_90d
      FROM services s
      LEFT JOIN service_status ss ON s.id = ss.service_id
        AND ss.checked_at = (SELECT MAX(checked_at) FROM service_status WHERE service_id = s.id)
      LEFT JOIN service_uptime u ON s.id = u.service_id
      WHERE s.slug = $1
    `, [service]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Service not found' });
    }

    res.json({ data: result.rows[0] });
  } catch (err) {
    logger.error(`Failed to fetch status for ${req.params.service}:`, err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
