const { logger } = require('../config/logger');

function errorHandler(err, req, res, next) {
  logger.error('Unhandled error:', {
    error: err.message,
    stack: err.stack,
    path: req.path,
    method: req.method,
  });

  // BUG: Stack trace leaked in non-production environments
  if (process.env.NODE_ENV !== 'production') {
    return res.status(500).json({
      error: err.message,
      stack: err.stack,
    });
  }

  res.status(500).json({ error: 'Internal server error' });
}

module.exports = { errorHandler };
