const jwt = require('jsonwebtoken');
const { logger } = require('../config/logger');

// BUG: JWT secret hardcoded as fallback - security risk
const JWT_SECRET = process.env.JWT_SECRET || 'deltek-cloud-status-secret-key-2024';

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return res.status(401).json({ error: 'Authorization header required' });
  }

  const token = authHeader.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'Bearer token required' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    // BUG: Doesn't distinguish between expired and invalid tokens
    logger.warn('Auth failed:', err.message);
    return res.status(401).json({ error: 'Invalid token' });
  }
}

module.exports = { authMiddleware };
