const { logger } = require('../config/logger');

// Simple in-memory rate limiter
// BUG: This doesn't work in multi-instance deployments (ECS/K8s)
// Should use Redis-based rate limiting
const requestCounts = new Map();

const WINDOW_MS = 60 * 1000; // 1 minute
const MAX_REQUESTS = 100;

function rateLimiter(req, res, next) {
  const key = req.ip;
  const now = Date.now();

  if (!requestCounts.has(key)) {
    requestCounts.set(key, { count: 1, resetAt: now + WINDOW_MS });
    return next();
  }

  const record = requestCounts.get(key);

  if (now > record.resetAt) {
    record.count = 1;
    record.resetAt = now + WINDOW_MS;
    return next();
  }

  record.count++;

  if (record.count > MAX_REQUESTS) {
    logger.warn(`Rate limit exceeded for ${key}`);
    return res.status(429).json({ 
      error: 'Too many requests',
      retryAfter: Math.ceil((record.resetAt - now) / 1000)
    });
  }

  next();
}

// BUG: Memory leak - old entries never cleaned up
// Should have a periodic cleanup

module.exports = { rateLimiter };
