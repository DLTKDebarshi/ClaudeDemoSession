const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const { logger } = require('./config/logger');
const { connectDB } = require('./config/database');
const { connectRedis } = require('./config/redis');
const statusRoutes = require('./handlers/status');
const incidentRoutes = require('./handlers/incidents');
const metricsRoutes = require('./handlers/metrics');
const { authMiddleware } = require('./middleware/auth');
const { rateLimiter } = require('./middleware/rateLimiter');
const { errorHandler } = require('./middleware/errorHandler');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(helmet());
app.use(cors());
app.use(morgan('combined'));
app.use(express.json());
app.use(rateLimiter);

// Health check - no auth required
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    version: require('../package.json').version,
    uptime: process.uptime(),
    timestamp: new Date().toISOString()
  });
});

// API routes
app.use('/api/v1/status', authMiddleware, statusRoutes);
app.use('/api/v1/incidents', authMiddleware, incidentRoutes);
app.use('/api/v1/metrics', authMiddleware, metricsRoutes);

// Error handling
app.use(errorHandler);

// Startup
async function start() {
  try {
    await connectDB();
    await connectRedis();
    
    app.listen(PORT, () => {
      logger.info(`Cloud Status API running on port ${PORT}`);
      logger.info(`Environment: ${process.env.NODE_ENV}`);
    });
  } catch (err) {
    // BUG: error is logged but process doesn't exit cleanly
    console.log('Failed to start:', err);
  }
}

start();

module.exports = app;
