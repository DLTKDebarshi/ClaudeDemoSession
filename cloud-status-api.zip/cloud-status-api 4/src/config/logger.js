const winston = require('winston');

// BUG: Different log format in different environments but no way to distinguish
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    // TODO: Add Datadog transport
    // TODO: Add file transport for production
  ],
  // BUG: No default metadata (service name, environment)
});

module.exports = { logger };
