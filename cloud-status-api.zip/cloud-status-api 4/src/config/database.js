const { Pool } = require('pg');
const { logger } = require('./logger');

// Database connection configuration
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
  // BUG: No SSL configuration for production
  // BUG: No retry logic on connection failure
});

pool.on('error', (err) => {
  // BUG: This silently swallows connection errors
  console.log('Unexpected database error', err);
});

pool.on('connect', () => {
  logger.info('New database connection established');
});

async function connectDB() {
  try {
    const client = await pool.connect();
    const result = await client.query('SELECT NOW()');
    logger.info(`Database connected: ${result.rows[0].now}`);
    client.release();
  } catch (err) {
    // BUG: Catches error but doesn't re-throw - app starts without DB
    logger.error('Database connection failed:', err.message);
  }
}

async function query(text, params) {
  const start = Date.now();
  try {
    const result = await pool.query(text, params);
    const duration = Date.now() - start;
    // TODO: Add Datadog metric for query duration
    if (duration > 1000) {
      logger.warn(`Slow query (${duration}ms): ${text.substring(0, 100)}`);
    }
    return result;
  } catch (err) {
    logger.error(`Query failed: ${text}`, err);
    throw err;
  }
}

module.exports = { connectDB, query, pool };
