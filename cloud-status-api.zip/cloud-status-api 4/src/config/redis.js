const Redis = require('ioredis');
const { logger } = require('./logger');

let redis;

async function connectRedis() {
  redis = new Redis(process.env.REDIS_URL, {
    retryStrategy(times) {
      const delay = Math.min(times * 50, 2000);
      return delay;
    },
    maxRetriesPerRequest: 3,
  });

  redis.on('connect', () => {
    logger.info('Redis connected');
  });

  redis.on('error', (err) => {
    logger.error('Redis error:', err.message);
  });
}

async function getCached(key) {
  try {
    const data = await redis.get(key);
    return data ? JSON.parse(data) : null;
  } catch (err) {
    // Fail silently - cache miss is acceptable
    return null;
  }
}

async function setCache(key, data, ttlSeconds = 60) {
  try {
    await redis.setex(key, ttlSeconds, JSON.stringify(data));
  } catch (err) {
    logger.warn('Cache set failed:', err.message);
  }
}

module.exports = { connectRedis, getCached, setCache, getClient: () => redis };
