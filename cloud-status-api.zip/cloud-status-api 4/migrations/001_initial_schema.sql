-- Migration: 001_initial_schema.sql
-- Created: 2024-03-15
-- Author: Cloud Platform Team

CREATE TABLE services (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    display_order INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE service_status (
    id SERIAL PRIMARY KEY,
    service_id INTEGER REFERENCES services(id),
    status VARCHAR(20) NOT NULL CHECK (status IN ('operational', 'degraded', 'partial_outage', 'major_outage', 'maintenance')),
    response_time_ms INTEGER,
    error_message TEXT,
    checked_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- BUG: No index on service_id + checked_at - slow queries on large tables
-- BUG: No partitioning strategy for time-series data

CREATE TABLE incidents (
    id SERIAL PRIMARY KEY,
    service_id INTEGER REFERENCES services(id),
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    severity VARCHAR(5) NOT NULL CHECK (severity IN ('P1', 'P2', 'P3', 'P4')),
    status VARCHAR(20) NOT NULL DEFAULT 'investigating' CHECK (status IN ('investigating', 'identified', 'monitoring', 'resolved')),
    reported_by VARCHAR(100),
    resolved_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE service_uptime (
    id SERIAL PRIMARY KEY,
    service_id INTEGER REFERENCES services(id) UNIQUE,
    uptime_30d DECIMAL(5,2),
    uptime_60d DECIMAL(5,2),
    uptime_90d DECIMAL(5,2),
    total_incidents_30d INTEGER DEFAULT 0,
    mttr_minutes INTEGER DEFAULT 0,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Seed data
INSERT INTO services (name, slug, description, display_order) VALUES
    ('Payment API', 'payment-api', 'Credit card processing and tokenization', 1),
    ('User Auth', 'user-auth', 'Authentication and authorization service', 2),
    ('Data Pipeline', 'data-pipeline', 'ETL and real-time data processing', 3),
    ('Search Service', 'search-service', 'Elasticsearch-powered search', 4),
    ('Notification Engine', 'notification-engine', 'Email, SMS, and push notifications', 5),
    ('Analytics', 'analytics', 'Business intelligence and reporting', 6),
    ('File Storage', 'file-storage', 'S3-backed document management', 7),
    ('API Gateway', 'api-gateway', 'Rate limiting and request routing', 8);
