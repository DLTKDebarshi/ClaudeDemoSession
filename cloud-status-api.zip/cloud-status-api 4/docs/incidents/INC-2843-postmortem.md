# Post-Incident Review: INC-2843
# Costpoint ERP — Complete Outage

## Incident Summary
| Field | Detail |
|-------|--------|
| Incident ID | INC-2843 |
| Severity | P1 — Complete Outage |
| Service | Costpoint ERP |
| Duration | 1 hour 23 minutes |
| Start | May 12, 2026 03:12 UTC |
| Detected | May 12, 2026 03:14 UTC (PagerDuty) |
| Acknowledged | May 12, 2026 03:17 UTC |
| Mitigated | May 12, 2026 03:58 UTC (partial) |
| Resolved | May 12, 2026 04:35 UTC |
| Incident Commander | Sarah Chen (SRE) |
| Customers Affected | ~12,400 active sessions dropped |
| Revenue Impact | Estimated $47K (blocked timesheet submissions during APAC business hours) |

## Timeline

### Detection (03:12 - 03:17)
- 03:12 — Datadog alert: Costpoint login success rate dropped to 0% across all regions
- 03:13 — PagerDuty triggered P1 escalation to on-call SRE (Sarah Chen)
- 03:14 — Automated Slack notification posted to #costpoint-incidents
- 03:15 — Sarah acknowledged the page, began investigation
- 03:17 — Incident Commander role assumed, bridge call opened

### Investigation (03:17 - 03:42)
- 03:17 — Checked ECS service health: all tasks healthy, passing health checks on /health endpoint
- 03:20 — Checked ALB target group: all targets healthy (this was misleading — health check doesn't test auth)
- 03:22 — Attempted login from staging VPN: TLS handshake failure on auth.costpoint.deltek.com
- 03:25 — Checked ACM certificate: EXPIRED at 03:00 UTC. Auto-renewal had failed silently.
- 03:28 — Root cause identified: TLS certificate on auth gateway ALB expired
- 03:30 — Checked ACM renewal logs: renewal attempted on May 5, failed DNS validation
- 03:32 — DNS validation CNAME for the certificate had been accidentally deleted during a Route53 cleanup on April 28
- 03:35 — Contacted AWS Support for emergency certificate assistance
- 03:42 — Decision made to manually re-create validation CNAME and force renewal

### Mitigation (03:42 - 03:58)
- 03:42 — DNS validation CNAME re-created in Route53
- 03:45 — Triggered manual certificate renewal via AWS CLI
- 03:52 — New certificate issued by ACM
- 03:55 — ALB listener updated with new certificate ARN
- 03:58 — First successful login confirmed from monitoring

### Recovery (03:58 - 04:35)
- 03:58 — Login success rate recovering, 60% of normal
- 04:05 — Session cache warming, rate climbing
- 04:15 — 95% of normal login rate restored
- 04:35 — All metrics back to baseline, incident resolved
- 04:40 — Bridge call closed, Slack updated

## Root Cause Analysis

### Primary Cause
TLS certificate for auth.costpoint.deltek.com expired at 03:00 UTC on May 12. The certificate was managed by ACM with auto-renewal enabled, but the DNS validation CNAME record had been deleted.

### Contributing Factors
1. **No certificate expiration monitoring**: No Datadog monitor for ACM certificate expiration dates. The team relied entirely on ACM auto-renewal.
2. **DNS cleanup removed validation record**: On April 28, a Route53 cleanup script removed "unused" CNAME records, including the ACM validation record. The script had no safeguard for ACM validation CNAMEs.
3. **Silent renewal failure**: ACM attempted renewal on May 5 and failed DNS validation. No alert was generated — ACM failures only appear in CloudTrail, which nobody monitors for this.
4. **Health check gap**: ALB health checks hit /health on the app containers, not the auth endpoint. The service appeared healthy even though authentication was completely broken.
5. **No certificate in IaC**: The ACM certificate and its validation CNAME were created manually (ClickOps) in 2023. They were never added to Terraform, so the DNS cleanup script had no visibility.

## Impact
- 12,400 active sessions terminated
- All new logins failed for 1h 23m
- APAC region (peak business hours) most affected
- 847 support tickets filed
- Estimated $47K revenue impact from blocked timesheet submissions

## Action Items

| # | Action | Owner | Priority | Due Date | Status |
|---|--------|-------|----------|----------|--------|
| 1 | Add Datadog monitor for ACM certificate expiration (alert at 30, 14, 7 days) | SRE Team | P1 | May 15 | DONE |
| 2 | Import all ACM certificates and validation CNAMEs into Terraform | DevOps | P1 | May 22 | IN PROGRESS |
| 3 | Add CloudTrail alert for ACM renewal failures | SRE Team | P2 | May 22 | TODO |
| 4 | Update health check to include auth endpoint verification | Engineering | P2 | May 24 | TODO |
| 5 | Add safeguard to Route53 cleanup script: skip ACM validation CNAMEs | DevOps | P2 | May 19 | DONE |
| 6 | Document all manually-created resources that need Terraform import | DevOps | P3 | Jun 1 | TODO |
| 7 | Implement synthetic monitoring for end-to-end login flow | SRE Team | P3 | Jun 7 | TODO |
| 8 | Runbook: create incident response playbook for certificate failures | SRE Team | P3 | Jun 7 | TODO |

## Lessons Learned
- Auto-renewal is not a monitoring strategy. Always monitor expiration independently.
- Health checks must test critical user paths, not just container liveness.
- Any resource that exists outside IaC is a ticking time bomb.
- DNS cleanup automation needs deny-lists for infrastructure-critical records.
- APAC impact was disproportionate — consider regional redundancy for auth.
