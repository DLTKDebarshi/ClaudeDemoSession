# ADR-007: Service Status Check Architecture
# Date: 2024-03-15
# Status: ACCEPTED (needs review — see notes at bottom)
# Author: David Kim

## Context
We need to monitor the health and availability of 8 Deltek Cloud services (Costpoint, Vantagepoint, Maconomy, Dela AI, GovWin IQ, Cobra, Replicon, API Gateway). The system must provide real-time status to both internal dashboards and the customer-facing status page.

## Decision
We chose a polling-based architecture with a centralized status API:

1. **Polling Agent**: A cron job running every 30 seconds hits each service's health endpoint
2. **Storage**: Results stored in PostgreSQL (service_status table) — one row per check per service
3. **Caching**: Redis cache layer with 30-second TTL for dashboard reads
4. **API**: Express REST API serves cached status to consumers
5. **Retention**: 90 days of status history, older data deleted weekly

## Rationale
- Polling was chosen over push-based (webhook) because not all Deltek services expose webhooks
- PostgreSQL was chosen over a time-series DB (InfluxDB, TimescaleDB) for operational simplicity
- Single-region deployment (us-west-2) was chosen for cost savings

## Consequences

### Positive
- Simple to understand and operate
- No changes required on the monitored services
- Full history enables uptime calculations

### Negative
- Polling every 30 seconds for 8 services = ~1.6M rows/day in service_status
- PostgreSQL is not optimized for time-series data — table will grow rapidly
- No partitioning strategy was implemented
- Single-region means status API itself has a single point of failure
- 30-second polling interval means we can miss sub-30-second outages

## Review Notes (Added 2026-05-17)
This ADR was written in March 2024 when we had 3 services. We now have 8 and the service_status table is 48M rows / 21 GB. The original assumption that PostgreSQL would handle this volume is proving incorrect:
- Query performance is degrading
- VACUUM is struggling with table size
- The weekly DELETE for retention takes 22 seconds and locks writes

**Recommendation**: Revisit this ADR. Options to evaluate:
1. Partition service_status by month (least disruption)
2. Migrate to TimescaleDB extension (moderate disruption)
3. Move status data to a dedicated time-series database (most disruption)

See also: db-exports/db-health-report-may2026.md
