# On-Call Handoff Log — Cloud Platform Team
# Week of May 12-18, 2026
# Outgoing: Sarah Chen | Incoming: Marcus Rivera

## Active Issues Requiring Attention

### 1. Maconomy EU Reporting Latency (INC-2847) — ONGOING
- Started May 17 09:15 UTC
- Symptoms: EU reporting endpoint response times 5x normal (800ms+ vs 150ms baseline)
- Suspected: Connection pool saturation on EU read replica
- What I've tried: Increased pool size from 10 to 20 — no improvement. Checked replica lag (normal at 50ms). Datadog shows queries queueing at the application layer, not the database.
- Next steps: Check if the Maconomy batch job schedule changed. Last week's deploy added a new nightly reconciliation report — it may be running during EU business hours instead of overnight.
- Escalation: If latency exceeds 2000ms or error rate rises, escalate to P2 and page the Maconomy team (#maconomy-eng)

### 2. Costpoint T&E Maintenance Window (INC-2846) — PLANNED
- Scheduled May 17 06:00-10:00 UTC
- DB schema migration for timesheet approval workflow
- Status page updated, customer notification sent
- Rollback plan documented in JIRA CLOUD-4521
- DBA team is handling, you just need to verify the service comes back cleanly after the window

### 3. service_status Table Growth — NOT AN INCIDENT (YET)
- Table is at 48M rows / 21 GB
- Growth rate: ~1.6M rows/day
- Weekly cleanup DELETE is taking longer each week (22 seconds last run)
- This will become a P2 within 4-6 weeks if we don't implement partitioning
- Proposal in JIRA CLOUD-4498, needs DBA team review

## Things That Happened This Week

### P1: Costpoint Login Outage (INC-2843) — RESOLVED
- Full postmortem in docs/incidents/INC-2843-postmortem.md
- TL;DR: ACM cert expired because DNS validation CNAME was deleted during Route53 cleanup
- Action items being tracked, 2 of 8 completed
- Sarah/DevOps importing all ACM certs into Terraform this week

### P2: Vantagepoint 503 Errors (INC-2845) — RESOLVED
- Auto-scaling policy was too slow to respond to batch job + normal traffic overlap
- Fixed: Reduced scale-up cooldown from 300s to 120s, added predictive scaling
- Monitor for recurrence on Wednesday nights (batch job schedule)

### P2: Dela AI Inference Delays (INC-2842) — RESOLVED
- GPU instance cold-start after model update deployment
- Fixed: Pre-warming script added to deployment pipeline
- No further action needed

## Monitoring Gaps I Found This Week
- No alert for ACM certificate expiration (now fixed — Action Item #1 from INC-2843)
- No alert for connection pool utilization > 80% on any service
- Datadog synthetic check for Costpoint login flow still not implemented (CLOUD-4502)
- service_status table size has no automated alert — only shows up in weekly DBA report

## Upcoming Scheduled Events
- May 19 (Mon): Cobra EVM patch deployment (v3.8.3) — automated, monitor for rollback
- May 21 (Wed): Vantagepoint batch job runs 02:00 UTC — watch for auto-scaling behavior
- May 22 (Thu): DBA team maintenance window 04:00-06:00 UTC — pg_stat_statements enablement
- May 24 (Sat): Monthly RDS backup rotation — historically causes Replicon replica lag

## Contacts
- Maconomy team: #maconomy-eng, lead: Priya Sharma
- Costpoint team: #costpoint-eng, lead: David Kim
- DBA team: #dba-team, on-call DBA this week: Jen Okafor
- AWS TAM: James Wu (for ACM cert escalations)
