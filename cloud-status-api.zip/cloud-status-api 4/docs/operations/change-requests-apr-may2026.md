# Change Request Log — Cloud Status API
# Source: ServiceNow Export
# Period: April 15 - May 17, 2026

| CR Number | Date | Type | Title | Requestor | Approver | Environment | Risk | Status | Outcome |
|-----------|------|------|-------|-----------|----------|-------------|------|--------|---------|
| CHG-8847 | May 17 | Standard | Costpoint T&E schema migration — timesheet approval workflow | Jen Okafor | David Kim | Production | Medium | In Progress | Pending |
| CHG-8842 | May 15 | Standard | Enable pg_stat_statements on cloud-status-db | Marcus Rivera | Jen Okafor | Production | Low | Approved | Scheduled May 22 |
| CHG-8839 | May 12 | Emergency | ACM certificate renewal — auth.costpoint.deltek.com | Sarah Chen | Auto-approved (P1) | Production | High | Completed | Success |
| CHG-8835 | May 8 | Standard | Dela AI model update — inference engine v2.4 | Ravi Patel | Priya Sharma | Production | Medium | Completed | Success (with incident INC-2842) |
| CHG-8830 | May 5 | Standard | Add predictive auto-scaling to Vantagepoint ECS | Sarah Chen | Marcus Rivera | Production | Low | Completed | Success |
| CHG-8825 | May 1 | Standard | Cobra EVM upgrade to v3.8.2 — IPMDAR compliance | Alex Torres | David Kim | Production | Medium | Completed | Success |
| CHG-8820 | Apr 28 | Standard | Route53 DNS cleanup — remove unused CNAMEs | Marcus Rivera | Sarah Chen | Production | Low | Completed | CAUSED INC-2843 |
| CHG-8818 | Apr 28 | Standard | RDS engine patch — PostgreSQL 15.4.1 | Jen Okafor | Marcus Rivera | Production | Medium | Completed | CAUSED INC-2839 (rolled back) |
| CHG-8812 | Apr 22 | Standard | Update S3 bucket policy for new CIDR range | DevOps Bot | Auto-approved | Production | Low | Completed | CAUSED INC-2838 |
| CHG-8805 | Apr 18 | Standard | Increase ECS task memory from 512MB to 1024MB | Sarah Chen | Marcus Rivera | Production | Low | Completed | Success |
| CHG-8800 | Apr 15 | Standard | Add Datadog APM to Replicon service | Ravi Patel | Sarah Chen | Production | Low | Completed | Success |

## Summary
- Total changes: 11
- Successful: 7 (64%)
- Caused incidents: 3 (27%)
- Emergency: 1 (9%)

## CONCERN: 3 of 11 standard changes caused incidents in the past 30 days.
## Changes CHG-8820, CHG-8818, and CHG-8812 all had "Low" or "Medium" risk ratings but caused production incidents.
## Risk assessment process may need review.
