# Database Health Report — cloud-status-db
# Generated: 2026-05-17 10:00 UTC
# Source: RDS PostgreSQL 15.4 (db.r6g.xlarge)
# Region: us-west-2

## Instance Metrics
- Instance: db.r6g.xlarge (4 vCPU, 32 GB RAM)
- Storage: 187 GB used / 500 GB allocated (gp3)
- Connections: 14 active / 20 max pool
- Read Replicas: 0 (NONE CONFIGURED)
- Multi-AZ: Enabled (production)
- Backup Retention: 7 days
- Encryption: AES-256 (at rest)

## Table Sizes

| Table | Row Count | Table Size | Index Size | Total Size | Bloat % |
|-------|-----------|------------|------------|------------|---------|
| service_status | 48,291,040 | 12.4 GB | 8.7 GB | 21.1 GB | 34% |
| incidents | 2,847 | 1.2 MB | 896 KB | 2.1 MB | 8% |
| services | 8 | 16 KB | 32 KB | 48 KB | 0% |
| service_uptime | 8 | 8 KB | 16 KB | 24 KB | 0% |

## CRITICAL: service_status table analysis
- 48M+ rows, growing ~1.6M rows/day (8 services × 2 checks/min × 1440 min)
- No partitioning — single table holds ALL historical data
- 34% bloat — VACUUM not running frequently enough
- Index on (service_id, checked_at) exists but is 8.7 GB
- Missing index on (checked_at) alone — range queries do full index scans
- 90-day retention DELETE runs weekly, takes 22 seconds, locks table

## Index Analysis

| Index Name | Table | Columns | Size | Scans/Day | Usage |
|------------|-------|---------|------|-----------|-------|
| service_status_pkey | service_status | id | 3.2 GB | 0 | UNUSED — consider dropping |
| idx_service_status_service_checked | service_status | service_id, checked_at DESC | 5.5 GB | 12,450 | HIGH |
| incidents_pkey | incidents | id | 64 KB | 234 | NORMAL |
| services_pkey | services | id | 16 KB | 48,000 | HIGH |
| services_slug_key | services | slug | 16 KB | 24,000 | HIGH |

## WARNINGS
1. PRIMARY KEY index on service_status (3.2 GB) has ZERO scans — all queries use the composite index. Consider if PK is needed or if the composite could serve as PK.
2. No read replicas configured — all read and write traffic hits primary. Dashboard read queries are competing with status check writes.
3. Connection pool at 14/20 (70%) — approaching saturation during peak.
4. No pg_stat_statements extension enabled — cannot track query performance trends.
5. autovacuum_vacuum_cost_delay is at default (2ms) — should be reduced for large tables.

## Recommendations (Priority Order)
1. **CRITICAL**: Partition service_status by month — table is 21 GB and growing
2. **HIGH**: Add read replica for dashboard queries
3. **HIGH**: Enable pg_stat_statements for query performance tracking
4. **MEDIUM**: Drop unused PK index on service_status (saves 3.2 GB)
5. **MEDIUM**: Tune autovacuum for service_status (reduce cost_delay to 0)
6. **LOW**: Add monitoring for connection pool saturation
