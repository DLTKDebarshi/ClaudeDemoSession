const request = require('supertest');
const app = require('../src/index');

describe('Health Check', () => {
  it('should return 200 with status healthy', async () => {
    const res = await request(app).get('/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('healthy');
  });
});

// BUG: Only 1 test - no coverage for status, incidents, or metrics endpoints
// BUG: No integration tests
// BUG: No load tests
// TODO: Add tests for auth middleware
// TODO: Add tests for rate limiter
// TODO: Add tests for error handler
