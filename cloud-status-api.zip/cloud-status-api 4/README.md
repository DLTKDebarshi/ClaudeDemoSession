# Cloud Status API

A microservice that monitors the health and availability of Deltek Cloud platform services. Provides real-time status endpoints consumed by the internal dashboard and external status page.

## Architecture

- **Runtime**: Node.js 20 (Express)
- **Database**: PostgreSQL 15 (AWS RDS, multi-AZ)
- **Cache**: Redis 7 (ElastiCache)
- **Infrastructure**: Terraform → ECS Fargate (us-west-2)
- **CI/CD**: GitHub Actions → ECR → ArgoCD
- **Monitoring**: Datadog APM + custom metrics

## Quick Start

```bash
# Install dependencies
npm install

# Run locally
docker-compose up

# Run tests
npm test

# Lint
npm run lint
```

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Service health check |
| `/api/v1/status` | GET | All service statuses |
| `/api/v1/status/:service` | GET | Single service status |
| `/api/v1/incidents` | GET | Active incidents |
| `/api/v1/incidents` | POST | Report new incident |
| `/api/v1/metrics/uptime` | GET | Uptime percentages (30/60/90 day) |

## Team

- **Owner**: Cloud Platform Team
- **Slack**: #cloud-platform-eng
- **On-call**: PagerDuty rotation "cloud-status"

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `DATABASE_URL` | PostgreSQL connection string | Yes |
| `REDIS_URL` | Redis connection string | Yes |
| `DD_API_KEY` | Datadog API key | Yes |
| `PORT` | Server port (default: 3000) | No |
| `NODE_ENV` | Environment (development/staging/production) | Yes |
| `AWS_REGION` | AWS region | Yes |
