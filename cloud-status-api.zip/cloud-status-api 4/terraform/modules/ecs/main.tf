################################################################################
# ECS Fargate Service for Cloud Status API
################################################################################

resource "aws_ecs_cluster" "status" {
  name = "cloud-status-cluster"

  setting {
    name  = "containerInsights"
    value = "enabled"
  }

  tags = {
    team        = "cloud-platform"
    environment = "production"
    cost-center = "CC-2847"
  }
}

resource "aws_ecs_task_definition" "status_api" {
  family                   = "cloud-status-api"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = 512
  memory                   = 1024
  execution_role_arn       = aws_iam_role.ecs_execution.arn
  task_role_arn           = aws_iam_role.ecs_task.arn

  container_definitions = jsonencode([
    {
      name  = "cloud-status-api"
      image = "${var.ecr_repo_url}:latest"  # BUG: Using 'latest' tag

      portMappings = [
        {
          containerPort = 3000
          protocol      = "tcp"
        }
      ]

      environment = [
        { name = "NODE_ENV", value = "production" },
        { name = "PORT", value = "3000" },
        { name = "AWS_REGION", value = var.aws_region },
      ]

      secrets = [
        { name = "DATABASE_URL", valueFrom = var.db_secret_arn },
        { name = "REDIS_URL", valueFrom = var.redis_secret_arn },
        { name = "DD_API_KEY", valueFrom = var.dd_api_key_arn },
      ]

      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = "/ecs/cloud-status-api"
          "awslogs-region"        = var.aws_region
          "awslogs-stream-prefix" = "ecs"
        }
      }

      healthCheck = {
        command     = ["CMD-SHELL", "curl -f http://localhost:3000/health || exit 1"]
        interval    = 30
        timeout     = 5
        retries     = 3
        startPeriod = 60
      }
    }
  ])

  tags = {
    team        = "cloud-platform"
    environment = "production"
    cost-center = "CC-2847"
  }
}

resource "aws_ecs_service" "status_api" {
  name            = "cloud-status-api"
  cluster         = aws_ecs_cluster.status.id
  task_definition = aws_ecs_task_definition.status_api.arn
  desired_count   = 3
  launch_type     = "FARGATE"

  network_configuration {
    subnets         = var.private_subnet_ids
    security_groups = [aws_security_group.ecs.id]
  }

  load_balancer {
    target_group_arn = var.target_group_arn
    container_name   = "cloud-status-api"
    container_port   = 3000
  }

  # BUG: No deployment circuit breaker configured
  # BUG: No auto-scaling policy

  tags = {
    team        = "cloud-platform"
    environment = "production"
    cost-center = "CC-2847"
  }
}
