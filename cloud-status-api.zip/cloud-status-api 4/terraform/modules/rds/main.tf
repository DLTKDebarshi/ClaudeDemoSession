################################################################################
# RDS PostgreSQL Instance for Cloud Status API
# Owner: Cloud Platform Team
# Last modified: 2024-09-15
################################################################################

resource "aws_db_instance" "status_db" {
  identifier     = "cloud-status-db"
  engine         = "postgres"
  engine_version = "15.4"

  # BUG: Hardcoded instance class - should vary by environment
  instance_class = "db.r6g.xlarge"

  allocated_storage     = 100
  max_allocated_storage = 500
  storage_type          = "gp3"
  storage_encrypted     = true

  db_name  = "cloud_status"
  username = "statusadmin"
  # BUG: Password in plaintext - should use Secrets Manager
  password = "Pr0duction-Passw0rd-2024!"

  # BUG: Multi-AZ hardcoded to true even for dev
  multi_az = true

  vpc_security_group_ids = [aws_security_group.rds.id]
  db_subnet_group_name   = aws_db_subnet_group.status.name

  backup_retention_period = 7
  backup_window          = "03:00-04:00"
  maintenance_window     = "Mon:04:00-Mon:05:00"

  # BUG: deletion_protection should be true for production
  deletion_protection = false
  skip_final_snapshot = true

  # BUG: No performance insights enabled
  # BUG: No enhanced monitoring

  # MISSING: cost allocation tags
  tags = {
    Name = "cloud-status-db"
    # Missing: team, environment, cost-center tags
  }
}

resource "aws_security_group" "rds" {
  name_prefix = "cloud-status-rds-"
  vpc_id      = var.vpc_id

  ingress {
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    # BUG: Overly permissive - allows all IPs in VPC
    cidr_blocks     = [var.vpc_cidr]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_db_subnet_group" "status" {
  name       = "cloud-status-db-subnet"
  subnet_ids = var.private_subnet_ids
}
