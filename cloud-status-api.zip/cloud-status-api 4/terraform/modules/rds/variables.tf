variable "vpc_id" {
  description = "VPC ID for the RDS instance"
  type        = string
}

variable "vpc_cidr" {
  description = "VPC CIDR block"
  type        = string
}

variable "private_subnet_ids" {
  description = "Private subnet IDs for the DB subnet group"
  type        = list(string)
}

# BUG: No variable for environment - everything is hardcoded
# BUG: No variable for instance_class - can't change per environment
# BUG: No variable for multi_az - pays for multi-AZ in dev
